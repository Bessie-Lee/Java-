package com.booking.main;
import javax.swing.JFrame;
import com.booking.view.MainView;
public class Main {
	public static void main(String[] args) {
		MainView mainView = new MainView();
		mainView.setVisible(true);	
		String filepath = "img/音乐.wav";
		Musicstuff musicobject = new Musicstuff();	
		musicobject.playMusic (filepath);
	}
}
//1、将时钟换成电子钟表
//2、在界面添加音乐-
//3、完成退票与改签的独立实现
//4、购票成功跳转到选座位二级界面
//5、支付界面创新

//111111111111111111