/**  
 * @Title: BookingView.java
 * @Package com.booking.view
 * @author 姜向阳
 * @date 2018年7月3日
 * @version V1.0  
 */
package com.booking.view;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRootPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import com.booking.constants.Constants;
import com.booking.entity.Ticket;
import com.booking.model.Booking;
import com.booking.util.CalendarPanel;
import com.booking.util.DateFormatUtil;
import com.booking.util.ViewBackgroundUtil;


public class 银行卡界面 extends BaseFrameView implements ActionListener{

	/**
	 * @Fields serialVersionUID
	 */
	private static final long serialVersionUID = 2870945371327830406L;

	private JButton confirmBtn;
	/**
	 * @Fields backBtn : 返回按钮
	 */
	private JButton backBtn;
	
	public 银行卡界面() {
		init();
	}

	private void init() {
		// 设置背景图片
		ViewBackgroundUtil.setBG(this, "img/yhk.png");
		
		// 实例化确认按钮
		confirmBtn = new CustomButton(540, 480, CustomButton.RIGHT);
		confirmBtn.setText("确定支付");
		confirmBtn.setForeground(Color.BLACK);
		confirmBtn.setFont(new Font("宋体", Font.PLAIN, 16));
		confirmBtn.addActionListener(this);
		confirmBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
					
				JOptionPane.showMessageDialog(null, "银行卡支付成功！",
						"支付成功！",  JOptionPane.INFORMATION_MESSAGE);
				银行卡界面.this.setVisible(false);
			}
		});
	
		
		// 实例化返回按钮
		backBtn = new CustomButton(160, 480, CustomButton.LEFT);
		backBtn.setText("返回");
		backBtn.addActionListener(this);
		backBtn.setActionCommand("backToMainView");
		backBtn.setForeground(Color.BLACK);
		backBtn.setFont(new Font("宋体", Font.PLAIN, 16));
		backBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				银行卡界面.this.setVisible(false);
			}
		});

		this.add(backBtn);
		this.add(confirmBtn);
		this.setTitle("购票窗口");
		// 设置窗口无标题栏
		this.setUndecorated(true);
		this.getRootPane().setWindowDecorationStyle(JRootPane.NONE);
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}

}

		

