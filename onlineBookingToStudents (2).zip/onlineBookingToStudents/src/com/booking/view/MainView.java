
package com.booking.view;
import java.awt.*;
import java.util.Date;
import javax.swing.*;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Stroke;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
 
import javax.swing.JPanel;
import javax.swing.text.Highlighter.Highlight;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.Toolkit;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.image.BufferedImage;
import java.net.URL;
import java.text.DateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Stroke;
import java.text.SimpleDateFormat;

import javax.swing.JPanel;
import javax.swing.text.Highlighter.Highlight;
import java.awt.*;

import java.awt.*;

import javax.swing.*;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Time;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;


import java.awt.*;
import java.awt.event.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import javax.swing.*;

import java.util.*;
import javax.swing.*;

import java.awt.*;
import java.util.*;
import java.lang.Thread;
import java.text.DecimalFormat;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;

import com.booking.util.ViewBackgroundUtil;



import java.awt.*;
import java.util.*;
 
import javax.swing.*;
import java.awt.BorderLayout;
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

import java.text.SimpleDateFormat;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class MainView extends BaseFrameView implements ActionListener{

	/**
	 * @Fields serialVersionUID
	 */
	private static final long serialVersionUID = 8142213655847297255L;

	private ActionListener actionListener;
	/**
	 * @Fields bookingBtn : 购票按钮
	 */
	private JButton bookingBtn;
	/**
	 * @Fields checkinBtn : 退票
	 */
	private JButton alterBtn;
	
	/**
	 * @Fields checkinBtn : 改签
	 */
	private JButton changingBtn;
	
	/**
	 * @Fields checkinBtn : 值机按钮
	 */
	private JButton checkinBtn;
	/**
	 * @Fields exitBtn : 退出按钮
	 */
	private JButton exitBtn;

	public MainView() {
		
		init();
	}

	private void init() {		
		// 设置背景图片
		ViewBackgroundUtil.setBG(this, "img/bg6.png");
		// 实例化购票按钮
		bookingBtn = new CustomButton(100, 400, CustomButton.LEFT);
		bookingBtn.setText("购票");
		bookingBtn.addActionListener(this);
		bookingBtn.setActionCommand("bookingBtn");
		bookingBtn.setFont(new Font("宋体", Font.PLAIN, 16));
		bookingBtn.setForeground(Color.BLACK);
		
		// 实例退改签按钮
		alterBtn = new CustomButton(100, 500, CustomButton.LEFT);
		alterBtn.setText("退票");
		alterBtn.addActionListener(this);
		alterBtn.setActionCommand("alterBtn");
		alterBtn.setFont(new Font("宋体", Font.PLAIN, 16));
		alterBtn.setForeground(Color.BLACK);
		
		changingBtn = new CustomButton(540, 500, CustomButton.RIGHT);
		changingBtn.setText("改签");
		changingBtn.addActionListener(this);	
		changingBtn.setActionCommand("changingBtn");
		changingBtn.setFont(new Font("宋体", Font.PLAIN, 16));
		changingBtn.setForeground(Color.BLACK);
		
		// 实例化值机按钮
		checkinBtn = new CustomButton(540, 400, CustomButton.RIGHT);
		checkinBtn.setText("选座");
		checkinBtn.addActionListener(this);
		checkinBtn.setActionCommand("checkinBtn");
		checkinBtn.setFont(new Font("宋体", Font.PLAIN, 16));
		checkinBtn.setForeground(Color.BLACK);
		
		// 实例退出按钮
		exitBtn = new CustomButton(310, 450, CustomButton.RIGHT);
		exitBtn.setText("退出系统");
		exitBtn.addActionListener(this);		
		exitBtn.setFont(new Font("宋体", Font.PLAIN, 16));
		exitBtn.setForeground(Color.BLACK);
			
		JLabel welcomelabel2 = new JLabel("欢迎来到在线飞机购票系统！");
		welcomelabel2.setBounds(380, 100, 400, 30);	
		welcomelabel2.setFont(new Font("宋体", Font.PLAIN, 30));
		welcomelabel2.setForeground(Color.YELLOW);

		
		JLabel welcomelabel = new JLabel("安全机行，为你护航");
		welcomelabel.setBounds(110, 200, 400, 30);	
		welcomelabel.setFont(new Font("宋体", Font.PLAIN, 20));
		welcomelabel.setForeground(Color.ORANGE);
		
		JLabel welcomelabe3 = new JLabel("学号：2020122000518");
		welcomelabe3.setBounds(660, 8, 400, 30);	
		welcomelabe3.setFont(new Font("宋体", Font.PLAIN, 18));
		welcomelabe3.setForeground(Color.black);
		
		JLabel welcomelabe4 = new JLabel("    姓名：李妍妍");
		welcomelabe4.setBounds(660, 30, 400, 30);	
		welcomelabe4.setFont(new Font("宋体", Font.PLAIN, 18));
		welcomelabe4.setForeground(Color.black);
//
		// 转换日期显示格式
//		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//		JLabel time = new JLabel(df.format(new Date(System.currentTimeMillis())));
//		time.setBounds(630, 30, 200, 30);
//		time.setFont(new Font("宋体", Font.PLAIN, 20));
//		time.setForeground(Color.orange);
//
//		Timer timeAction = new Timer(1000, new ActionListener() {
//
//			@Override
//			public void actionPerformed(ActionEvent e) {
//				long timemillis = System.currentTimeMillis();
//
//				time.setText(df.format(new Date(timemillis)));
//			}
//		});
//		timeAction.start();
	
//		 


		 class Clock extends JComponent{
		    /**
		     *
		     */
		    private static final long serialVersionUID = -5379472973578609775L;
		    private Font f = new Font("宋体",Font.PLAIN,15);
		    private Font f2 = new Font("宋体",Font.BOLD,15);
		    private JLabel l = new JLabel("当前时间：");
		    private JLabel display = new JLabel();
		    private JLabel display2 = new JLabel("");
		    private int hour = 0;
		    private int min = 0;
		    private int sec = 0;
		    private Date now = new Date();
		    private Graphics2D g;
		    final double PI = Math.PI;
		    private String strTime = "" ;

		    @SuppressWarnings("deprecation")
		    public Clock(){
		        add(l);
		        l.setBounds(120, 320, 80, 20);
		        l.setFont(f);
		        add(display);
		        display.setBounds(195, 320, 80, 20);
		        display.setFont(f);
		        display.setBorder(BorderFactory.createLineBorder(Color.blue));
		        add(display2);
		        display2.setBounds(90, 350, 250, 20);
		        display2.setFont(f);
		        hour = now.getHours();
		        min = now.getMinutes();
		        sec = now.getSeconds();
		        setVisible(true);
		    }

		    public void paintComponent(Graphics g1){
		        double x,y;
		        super.paintComponent(g1);
		        g = (Graphics2D) g1;
		        //反锯齿开关开
		        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

		        //画表盘
		        g.setPaint(new GradientPaint(5,40,Color.white,15,50,Color.white,true));
		        g.setStroke( new BasicStroke(3,BasicStroke.CAP_BUTT,BasicStroke.JOIN_BEVEL));
		        g.drawOval(75, 40, 250, 250);
		        g.fillOval(195, 160, 10, 10);
		        g.setColor(Color.white);

		        //画60个点
		        for(int i = 0;i < 60;i++)
		        {
		            double[] co = new double[2];
		            co = paint_Dot(i * 2 * PI / 60);
		            x = co[0];
		            y = co[1];
		            if(i == 0 || i == 15 || i == 30 || i == 45)//画3,6,9,12四个大点
		            {
		                g.fillOval((int)(x - 5 + 200),(int)(y - 5 + 165),10,10);
		            }
		            else//其他小点
		            {
		                g.fillOval((int)(x - 2.5 + 200),(int)(y - 2.5 + 165),5,5);
		            }
		        }

		        //画四个数字
		        g.setFont(f2);
		        g.drawString("3", 300, 171);
		        g.drawString("6", 195, 273);
		        g.drawString("9", 91, 171);
		        g.drawString("12", 190, 68);

		        //画时针，分针，秒针
		        paint_HourPointer(hour*3600 + min*60 + sec,g);//时针走过的秒数
		        paint_MinutePointer(min*60 + sec,g);//分针走过的秒数
		        paint_SecondPointer(sec,g);//秒针走过的秒数
		    }

		    public void showUI(){
		        new Thread() {
		            @SuppressWarnings("deprecation")
		            public void run() {
		                while (true)
		                {
		                    now = new Date();
		                    hour = now.getHours();
		                    min = now.getMinutes();
		                    sec = now.getSeconds();
		                    try {
		                        Thread.sleep(1000);
		                    } catch (InterruptedException ex) {
		                        ex.printStackTrace();
		                    }
		                    showTime();
		                    repaint();
		                }
		            }
		        }.start();
		    }

		    public void paint_HourPointer(int second,Graphics2D g){//second表示当前时间的时针相对00:00:00走了多少秒
		        double x,y,angle;
		        angle = second * PI / 21600;//时针的速度为PI/21600 (rad/s)
		        x = 200 + 60 * Math.sin(angle);
		        y = 165 - 60 * Math.cos(angle);
		        g.setStroke( new BasicStroke(5,BasicStroke.CAP_BUTT,BasicStroke.JOIN_ROUND));
		        g.setPaint(new GradientPaint(200,165,Color.black,260,165,Color.black,true));
		        g.drawLine(200, 165, (int)x, (int)y);
		    }

		    public void paint_MinutePointer(int second,Graphics2D g){//second表示当前时间的分针相对00:00:00走了多少秒
		        double x,y,angle;
		        angle = second * PI / 1800;//分针的速度为PI/1800 (rad/s)
		        x = 200 + 80 * Math.sin(angle);
		        y = 165 - 80 * Math.cos(angle);
		        g.setStroke( new BasicStroke(3,BasicStroke.CAP_BUTT,BasicStroke.JOIN_ROUND));
		        g.setPaint(new GradientPaint(200,165,Color.black,280,165,Color.black,true));
		        g.drawLine(200, 165, (int)x, (int)y);
		    }

		    public void paint_SecondPointer(int second,Graphics2D g){//second表示当前时间的秒针相对00:00:00走了多少秒
		        double x,y,x1,y1,x2,y2,x3,y3,angle;
		        double cos = 90 / Math.sqrt(8125);//90*90+5*5
		        double sin = 5 / Math.sqrt(8125);
		        angle = second * PI / 30;//时针的速度为PI/30 (rad/s)
		        x = 200 + 95 * Math.sin(angle);
		        y = 165 - 95 * Math.cos(angle);
		        x1 = 200 + 20 * Math.sin(angle + PI);
		        y1 = 165 - 20 * Math.cos(angle + PI);
		        x2 = 200 + Math.sqrt(8125)* ( Math.sin(angle)*cos - Math.cos(angle)*sin ); //sin(a-b)
		        y2 = 165 - Math.sqrt(8125)* ( Math.cos(angle)*cos + Math.sin(angle)*sin ); //cos(a-b)
		        x3 = 200 + Math.sqrt(8125)* ( Math.sin(angle)*cos + Math.cos(angle)*sin ); //sin(a+b)
		        y3 = 165 - Math.sqrt(8125)* ( Math.cos(angle)*cos - Math.sin(angle)*sin ); //cos(a+b)
		        g.setStroke( new BasicStroke(2,BasicStroke.CAP_BUTT,BasicStroke.JOIN_BEVEL));
		        g.setPaint(new GradientPaint(180,165,Color.black,295,165,Color.black,true));
		        g.drawLine((int)x1, (int)y1, (int)x, (int)y);
		        g.drawLine((int)x2, (int)y2, (int)x, (int)y);
		        g.drawLine((int)x3, (int)y3, (int)x, (int)y);
		    }

		    public double[] paint_Dot(double angle){
		        double[] co = new double[2];
		        co[0] = 115 * Math.cos(angle);//横坐标
		        co[1] = 115 * Math.sin(angle);//纵坐标
		        return co;
		    }

		    @SuppressWarnings("deprecation")
		    private void showTime(){
		        String date;
		        int hour_temp = hour,min_temp = min,sec_temp = sec;
		        sec_temp += 1 ;
		        if(sec_temp >= 60)
		        {
		            sec_temp = 0;
		            min_temp += 1 ;
		        }
		        if(min_temp>=60){
		            min_temp=0;
		            hour_temp+=1;
		        }
		        if(hour_temp < 10)
		            strTime = "0" + hour_temp + ":";
		        else
		            strTime = "" + hour_temp + ":";

		        if(min_temp < 10)
		            strTime = strTime + "0" + min_temp + ":";
		        else
		            strTime = strTime + "" + min_temp + ":";

		        if(sec < 10)
		            strTime = strTime + "0" + sec_temp;
		        else
		            strTime = strTime + "" + sec_temp;
		      
		        
		        
		        display.setText(strTime);
		   
		    }

		 }
		        Clock c = new Clock();
		        c.showUI();
		        JFrame f = new JFrame();
		        Image img=Toolkit.getDefaultToolkit().getImage("title.gif");//窗口图标
		        f.setIconImage(img);
		        f.setSize(380,380);
		        f.setResizable(false);
		        f.add(c, BorderLayout.CENTER);
		        f.setLocationRelativeTo(null);
		        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		        f.setVisible(true);
	
		this.add(bookingBtn);
		this.add(alterBtn);
		this.add(changingBtn);
		this.add(checkinBtn);
		this.add(exitBtn);
		this.add(welcomelabel);
		this.add(welcomelabel2);
		this.add(welcomelabe3);
		this.add(welcomelabe4);
		this.add(c);
		//this.add(tm.frame);
		//this.add(time);
		 //设置窗口无标题栏
		this.setUndecorated(true);
		this.getRootPane().setWindowDecorationStyle(JRootPane.NONE);
		
		this.setTitle("在线购票系统");
		
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		String actionCommand = e.getActionCommand();
		// 根据不同按钮点击，显示不同窗口
		switch (actionCommand) {
		// 点击“购票”按钮
		case "bookingBtn":
			// 显示购票窗口
			BookingView bookingView = new BookingView();
			bookingView.setVisible(true);
			break;
			
			// 点击“退票/改签”按钮
		case "alterBtn":
			// 显示退票/改签窗口
			RefundOrAlterView refundOrAlterView = new RefundOrAlterView();
			refundOrAlterView.setVisible(true);
			break;
			
		case "changingBtn":
			changingView refundOrAlterView1 = new changingView();
			refundOrAlterView1.setVisible(true);
			break;
			
		// 点击“值机”按钮
		case "checkinBtn":
			// 显示值机窗口
			CheckinView checkinView = new CheckinView();
			checkinView.setVisible(true);
			break;
		case "退出系统":
			System.exit(0);
		}
}}
