/**  
* @Title: PayView.java
 * @Package com.booking.view
 * @author 姜向阳
 * @date 2018年7月3日
 * @version V1.0  
 */
package com.booking.view;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JRootPane;

import com.booking.util.ViewBackgroundUtil;

/**
 * @ClassName: PayView
 * @Description: 支付窗口
 * @since JDK 1.8
 */
public class PayView extends BaseFrameView {

	/**
	 * @Fields serialVersionUID
	 */
	private static final long serialVersionUID = 8142213655847297255L;

	private ActionListener actionListener;
	/**
	 * @Fields unionPayRadioBtn : 银联卡单选按钮
	 */
	private JRadioButton unionPayRadioBtn;
	/**
	 * @Fields aliPayRadioBtn : 支付宝单选按钮
	 */
	private JRadioButton aliPayRadioBtn;
	/**
	 * @Fields weChatRadioBtn : 微信单选按钮
	 */
	private JRadioButton weChatRadioBtn;
	/**
	 * @Fields confirmBtn : 确认按钮
	 */
	private JButton confirmBtn;
	/**
	 * @Fields backBtn : 返回按钮
	 */
	private JButton backBtn;
	/**
	 * @Fields selectedValue : 单选按钮选中值
	 */
	private String selectedValue;

	public PayView(String identityNo) {
		this.actionListener = actionListener;
		init();
	}

	private void init() {
		// 设置背景图片
		ViewBackgroundUtil.setBG(this, "img/bg7.png");
		// 单选按钮监听器
		ActionListener listener = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				JRadioButton temp=(JRadioButton)e.getSource();
				if(temp.isSelected()){
					selectedValue=temp.getText();
				}
				
			}
		};
		// 支付方式单选按钮列表标签
		JLabel noteLabel = new JLabel("请选择付款方式：");
		noteLabel.setBounds(340, 60, 120, 33);
		noteLabel.setFont(new Font("宋体", Font.PLAIN, 24));
		noteLabel.setForeground(Color.orange);

		
		// 实例化银联卡单选按钮
		unionPayRadioBtn = new JRadioButton("银联卡");
		unionPayRadioBtn.setSelected(true);
		selectedValue = "银联卡";
		unionPayRadioBtn.addActionListener(listener);
		unionPayRadioBtn.setBounds(120, 120, 90, 33);
		unionPayRadioBtn.setFont(new Font("宋体", Font.PLAIN, 16));
		unionPayRadioBtn.setForeground(Color.BLACK);
		
		// 实例化支付宝单选按钮
		aliPayRadioBtn = new JRadioButton("支付宝");
		aliPayRadioBtn.addActionListener(listener);
		aliPayRadioBtn.setBounds(340, 120, 90, 33);
		aliPayRadioBtn.setFont(new Font("宋体", Font.PLAIN, 16));
		aliPayRadioBtn.setForeground(Color.BLACK);
		
		// 实例化微信单选按钮
		weChatRadioBtn = new JRadioButton("微信");
		weChatRadioBtn.addActionListener(listener);
		weChatRadioBtn.setBounds(580, 120, 90, 33);
		weChatRadioBtn.setFont(new Font("宋体", Font.PLAIN, 16));
		weChatRadioBtn.setForeground(Color.BLACK);
		
		// 将单选按钮编组
		ButtonGroup group = new ButtonGroup();
		group.add(this.unionPayRadioBtn);
		group.add(this.aliPayRadioBtn);
		group.add(this.weChatRadioBtn);
		
		
		// 实例化确认按钮
		confirmBtn = new CustomButton(480, 440, CustomButton.RIGHT);
		confirmBtn.setText("支付");
		confirmBtn.addActionListener(actionListener);
		confirmBtn.setFont(new Font("宋体", Font.PLAIN, 16));
		confirmBtn.setForeground(Color.BLACK);
		confirmBtn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				if (selectedValue.equals("银联卡")) {
					银行卡界面 refund1 = new 银行卡界面();
					refund1.setVisible(true);
				} 
				if (selectedValue.equals("支付宝")) {
					//进入支付宝界面，需要实现图片已经代码
					支付宝界面 refund = new 支付宝界面();
					refund.setVisible(true);
				} 
				if (selectedValue.equals("微信")) {
					微信界面 refund2 = new 微信界面();
					refund2.setVisible(true);
					
				} 
				// 关闭支付方式选择窗口
				PayView.this.setVisible(false);

			}
		});
		
		// 实例化返回按钮
		backBtn = new CustomButton(180, 440, CustomButton.LEFT);
		backBtn.setText("返回");
		backBtn.setFont(new Font("宋体", Font.PLAIN, 16));
		backBtn.setForeground(Color.BLACK);
		backBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				PayView.this.setVisible(false);
			}
		});
		backBtn.setActionCommand("backBookingView");
		
		this.add(noteLabel);
		this.add(unionPayRadioBtn);
		this.add(aliPayRadioBtn);
		this.add(weChatRadioBtn);
		this.add(backBtn);
		this.add(confirmBtn);
		
		this.setLocationRelativeTo(null);
		// 设置窗口无标题栏
//		this.setUndecorated(true);
//		this.getRootPane().setWindowDecorationStyle(JRootPane.NONE);
	}
}
