/**  
 * @Title: OpenAccountView.java //据实修改
 * @Package com.atm.view //据实修改
 * @author 姜向阳  //据实修改
 * @date 2018年3月13日 //据实修改
 * @version V1.0  
 */
package com.booking.view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import com.booking.util.ViewBackgroundUtil;

/**
 * @ClassName: OpenAccountView   //据实修改
 * @Description: 开户界面
 * @since JDK 1.8
 */
public class RefundOrAlterView extends BaseFrameView implements ActionListener{

	/**
	 * @Fields serialVersionUID
	 */
	private static final long serialVersionUID = 2870945371327830406L;


	/**
	 * @Fields searchCondition : 搜索条件
	 */
	private JTextField searchCondition;
	
	/**
	 * @Fields confirmBtn : 确认按钮
	 */
	private JButton confirmBtn;
	/**
	 * @Fields backBtn : 返回按钮
	 */
	private JButton backBtn;

	public RefundOrAlterView() {
		init();
	}

	private void init() {
		// 设置背景图片
		ViewBackgroundUtil.setBG(this, "img/bg2.png");
		// 始发地标签
		JLabel noteLabel = new JLabel("请输入您购票时的身份证号：");
		noteLabel.setBounds(295, 60, 240, 33);
		
		// 搜索条件文本框
		searchCondition = new JTextField();
		searchCondition.setBounds(295, 100, 200, 33);
		
		// 实例化确认按钮
		confirmBtn = new CustomButton(480, 460, CustomButton.RIGHT);
		confirmBtn.setText("确认");
		confirmBtn.addActionListener(this);
		
		// 实例化返回按钮
		backBtn = new CustomButton(180, 460, CustomButton.LEFT);
		backBtn.setText("返回");
		backBtn.addActionListener(this);
		backBtn.setActionCommand("toMainView");

		this.add(noteLabel);
		this.add(searchCondition);
		this.add(backBtn);
		this.add(confirmBtn);
		
		this.setLocationRelativeTo(null);
		// 设置窗口无标题栏
//		this.setUndecorated(true);
//		this.getRootPane().setWindowDecorationStyle(JRootPane.NONE);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		String actionCommand = e.getActionCommand();
		switch (actionCommand) {
		case "toMainView":
			this.dispose();
			break;
			
		case "确认":
		
		// 获取输入的订单号或身份证号
		String inputItem =  searchCondition.getText();
		if ("".equals(inputItem)) {
			JOptionPane.showMessageDialog(RefundOrAlterView.this, "请输入身份证号或订单号:",
					"提示信息", JOptionPane.ERROR_MESSAGE);
			return;
		
			
		} else {
//			// 传递订单号或身份证号到订单窗口
			this.setVisible(true);
			AlterOrderView alterOrderView = new AlterOrderView(inputItem);
			alterOrderView.setVisible(true);
		}
		
	}}
}
